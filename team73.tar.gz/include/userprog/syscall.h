#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);

struct lock file_lock; //P2-3

#endif /* userprog/syscall.h */

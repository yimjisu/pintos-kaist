#include <stdint.h>

int int_to_fp (int);

int fp_to_int (int);

int fp_to_int_round (int);

int add_fp (int, int);

int sub_fp (int, int);

int add_fp_int (int, int);

int sub_fp_int (int, int);

int mult_fp (int, int);

int mult_fp_int(int, int);

int div_fp (int, int);

int div_fp_int (int, int); 